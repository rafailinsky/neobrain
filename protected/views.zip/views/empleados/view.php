<?php
/* @var $this EmpleadosController */
/* @var $model Empleados */

$this->breadcrumbs=array(
	'Empleadoses'=>array('index'),
	$model->idEmpleados,
);

$this->menu=array(
	array('label'=>'List Empleados', 'url'=>array('index')),
	array('label'=>'Create Empleados', 'url'=>array('create')),
	array('label'=>'Update Empleados', 'url'=>array('update', 'id'=>$model->idEmpleados)),
	array('label'=>'Delete Empleados', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->idEmpleados),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Empleados', 'url'=>array('admin')),
);
?>

<h1>View Empleados #<?php echo $model->idEmpleados; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'idEmpleados',
		'RFC_Empleados',
		'IMSS_Empleados',
		'Nombres_Empleados',
		'Apellido_Paterno_Empleados',
		'Apellido_Materno_Empleados',
		'Puesto_Empleados',
		'Sexo_Empleados',
		'Status_Empleados',
		'Status_IMSS_Empleados',
		'Papeles_Empleados',
	),
)); ?>
