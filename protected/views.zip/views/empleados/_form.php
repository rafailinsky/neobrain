<?php
/* @var $this EmpleadosController */
/* @var $model Empleados */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'empleados-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'RFC_Empleados'); ?>
		<?php echo $form->textField($model,'RFC_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'RFC_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'IMSS_Empleados'); ?>
		<?php echo $form->textField($model,'IMSS_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'IMSS_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Nombres_Empleados'); ?>
		<?php echo $form->textField($model,'Nombres_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Nombres_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Apellido_Paterno_Empleados'); ?>
		<?php echo $form->textField($model,'Apellido_Paterno_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Apellido_Paterno_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Apellido_Materno_Empleados'); ?>
		<?php echo $form->textField($model,'Apellido_Materno_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Apellido_Materno_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Puesto_Empleados'); ?>
		<?php echo $form->textField($model,'Puesto_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Puesto_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Sexo_Empleados'); ?>
		<?php echo $form->textField($model,'Sexo_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Sexo_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Status_Empleados'); ?>
		<?php echo $form->textField($model,'Status_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Status_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Status_IMSS_Empleados'); ?>
		<?php echo $form->textField($model,'Status_IMSS_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Status_IMSS_Empleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Papeles_Empleados'); ?>
		<?php echo $form->textField($model,'Papeles_Empleados',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'Papeles_Empleados'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->