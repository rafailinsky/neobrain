<?php
/* @var $this EmpleadosController */
/* @var $data Empleados */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idEmpleados')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idEmpleados), array('view', 'id'=>$data->idEmpleados)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RFC_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->RFC_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IMSS_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->IMSS_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Nombres_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Nombres_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Apellido_Paterno_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Apellido_Paterno_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Apellido_Materno_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Apellido_Materno_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Puesto_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Puesto_Empleados); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('Sexo_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Sexo_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Status_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Status_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Status_IMSS_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Status_IMSS_Empleados); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Papeles_Empleados')); ?>:</b>
	<?php echo CHtml::encode($data->Papeles_Empleados); ?>
	<br />

	*/ ?>

</div>