<?php
/* @var $this EmpleadosController */
/* @var $model Empleados */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'idEmpleados'); ?>
		<?php echo $form->textField($model,'idEmpleados'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'RFC_Empleados'); ?>
		<?php echo $form->textField($model,'RFC_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'IMSS_Empleados'); ?>
		<?php echo $form->textField($model,'IMSS_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Nombres_Empleados'); ?>
		<?php echo $form->textField($model,'Nombres_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Apellido_Paterno_Empleados'); ?>
		<?php echo $form->textField($model,'Apellido_Paterno_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Apellido_Materno_Empleados'); ?>
		<?php echo $form->textField($model,'Apellido_Materno_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Puesto_Empleados'); ?>
		<?php echo $form->textField($model,'Puesto_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Sexo_Empleados'); ?>
		<?php echo $form->textField($model,'Sexo_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Status_Empleados'); ?>
		<?php echo $form->textField($model,'Status_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Status_IMSS_Empleados'); ?>
		<?php echo $form->textField($model,'Status_IMSS_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Papeles_Empleados'); ?>
		<?php echo $form->textField($model,'Papeles_Empleados',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->